from django.apps import AppConfig


class PostAppConfig(AppConfig):
    name = 'post_app'
