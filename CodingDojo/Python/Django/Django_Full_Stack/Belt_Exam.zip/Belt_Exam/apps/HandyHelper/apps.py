from django.apps import AppConfig


class HandyhelperConfig(AppConfig):
    name = 'HandyHelper'
