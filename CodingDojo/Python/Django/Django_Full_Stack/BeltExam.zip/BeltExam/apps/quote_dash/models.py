from django.db import models
from django.contrib import messages
import bcrypt
# Our custom manager!
# No methods in our new manager should ever receive the whole request object as an argument!
# (just parts, like request.POST)
# Our custom manager!
# No methods in our new manager should ever receive the whole request object as an argument!
# (just parts, like request.POST)
class UserManager(models.Manager):
    def registration_validator(self, postData, request):
        isValid = True
        # add keys and values to errors dictionary for each invalid field
        if len(postData['first_name']) < 2:
            messages.warning(request, 'First name is not long enough.')
            isValid = False
        if len(postData['last_name']) < 2:
            messages.warning(request, 'Last name is not long enough.')
            isValid = False
        if len(postData['password']) < 8:
            messages.warning(request, 'Password is not long enough.')
            isValid = False
        if postData['password'] != postData['confirm_password']:
            messages.warning(request, 'Password do not match.')
            isValid = False
        if User.objects.filter(email = postData['email']):
            messages.error(request, "This email already exists.")
            isValid = False

        if isValid == True:
            messages.success(request, "Success! Welcome, " + postData['first_name'] + "!")
            hashed = bcrypt.hashpw(postData['password'].encode(), bcrypt.gensalt())
            User.objects.create(first_name = postData['first_name'], last_name = postData['last_name'], email = postData['email'], password = hashed)
        return isValid

    def user_exists(self, postData, request):
        isValid = True
        if User.objects.filter(email = postData['email']):
            hashed = User.objects.get(email = postData['email']).password
            hashed = hashed.encode('utf-8')
            password = postData['password']
            password = password.encode('utf-8')
            if bcrypt.hashpw(password, hashed) == hashed:
                messages.success(request, "Success! Welcome, " + User.objects.get(email = postData['email']).first_name + "!")
                isValid = True
            else:
                messages.warning(request, "Unsuccessful login. Incorrect password")
                isValid = False
        else:
            messages.warning(request, "Unsuccessful login. Your email is incorrect.")
            isValid = False
        return isValid

class AuthorManager(models.Manager):
    def author_validator(self, postData, request):
        isValid = True
        # add keys and values to errors dictionary for each invalid field
        if len(postData['authorBox']) == 0:
            messages.warning(request, 'Author can not be empty!')
        elif len(postData['authorBox']) < 4:
            messages.warning(request, 'Author is not long enough.')
            isValid = False

        
            # messages.success(request, "Success! Welcome, " + postData['first_name'] + postData['last_name'] + "!")
        return isValid

class QuoteManager(models.Manager):
    def quote_validator(self, postData, request):
        isValid = True
        # add keys and values to errors dictionary for each invalid field
        if len(postData['quoteBox']) == 0:
            messages.warning(request, 'Quote can not be empty!')
        elif len(postData['quoteBox']) < 10:
            messages.warning(request, 'Quote is not long enough.')
            isValid = False
        return isValid

class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.TextField()
    email = models.EmailField()
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()    # add this line for validation!


class Author(models.Model):
    user = models.ForeignKey(User, related_name='authors', on_delete=models.CASCADE)
    author = models.CharField(max_length=25)
    user_likes = models.ManyToManyField(User, related_name='u_likes', blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = AuthorManager()

class Quote(models.Model):
    user = models.ForeignKey(User, related_name='u_quote', on_delete=models.CASCADE)
    author = models.ForeignKey(Author, related_name='u_author', on_delete=models.CASCADE)
    quote = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = QuoteManager()