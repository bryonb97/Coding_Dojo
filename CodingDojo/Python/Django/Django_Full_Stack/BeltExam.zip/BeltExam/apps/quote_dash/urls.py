#---------------------------------------------------
# quote_dash urls.py 
#---------------------------------------------------
from django.conf.urls import url, include
from .import views

urlpatterns = [
    url(r'^$', views.index),
    url(r'^register$', views.register),
    url(r'^success$', views.success),
    url(r'^quote/delete/(?P<id>\d+)$', views.deleteQuote),   
    url(r'^user/(?P<id>\d+)$', views.editAccount),
    url(r'^updateUser/(?P<id>\d+)$', views.updateAccount),
    url(r'^editAccount/(?P<id>\d+)$', views.editAccount),
    url(r'^user/view/(?P<id>\d+)$', views.viewUsersQuotes),
    url(r'^like/(?P<id>\d+)$', views.userLiked),
    url(r'^add_quote$', views.createQuote),
    url(r'^login$', views.login),
    url(r'^logout$', views.logout),


]
