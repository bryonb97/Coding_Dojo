from django.shortcuts import render, redirect, HttpResponse, get_object_or_404
from django.contrib import messages
from .models import *

def index(request):
    return render(request, 'index.html')

def register(request):
    if User.objects.registration_validator(request.POST, request):
        isValid = True
        return redirect('/success')
    else:
        isValid = False
        return redirect('/')

def success(request):
    user = User.objects.get(email=request.session['email'])
    context = {
        'user':User.objects.get(email=user.email),
        'author_data':Author.objects.all(),
        'quote_data':Quote.objects.all(),
    }
    
    return render(request, 'QuoteHome.html',context)

def createQuote(request):
    if Quote.objects.quote_validator(request.POST, request):
        isValid = True
        user = User.objects.get(email=request.session['email']) # Usr.get gets one object. User.get gets an array of users.
        author = Author.objects.create(user=user, author=request.POST['quoteBox'])
        quote = Quote.objects.create(user=user, author=author, quote=request.POST['quoteBox'])
        print(f'================={quote.id}===========================')
        print(f'================={quote.user}===========================')
        print(f'================={quote.author}===========================')
        print(f'================={quote.quote}===========================')
        
        messages.success(request,'Quote posted successfully.')
        return redirect('/success')
    else:
        isValid = False
        return redirect('/success')

def viewUser(request, id):
    return redirect('/viewUsersQuotes/'+ id)

def viewUsersQuotes(request, id):
    user = User.objects.get(id=id) # Usr.get gets one object. User.get gets an array of users.
    context = {
        'quotes': Quote.objects.all(),
    }
    return render(request, 'UsersQuotes.html', context)

    

def deleteQuote(request, id):
    a = Author.objects.get(id=id)
    a.delete()
    return redirect('/success') 

def editAccount(request, id):
    user = User.objects.get(email=request.session['email']) # User.get gets one object. User.get gets an array of user objects.
    context = {
        'users': User.objects.get(email=request.session['email']),
    }
    return render(request, 'editAccount.html', context)

def updateAccount(request, id):    
    #validate that email doesn't already exist in database
    user = User.objects.get(email=request.session['email'])
    print(f'==========={user.email}==================')
    if request.POST['email'] != user.email: # Check if email entered is different from the users email
        messages.success(request, "Email updated successfully!")
    elif user != "":
        messages.error(request,"This email has already been registered")
    else:
        new_user = User.objects.update(first_name=request.POST['first_name'], last_name=request.POST['last_name'], email=request.POST['email'])
        new_user.save()
        messages.success(request, "User updated successfully!")
        print(f'==========={new_user.email}==================')
    return redirect('/editAccount/' + id)

def userLiked(request, id):
    user = User.objects.get(email=request.session['email'])
    author = User.objects.get(email=request.session['email'])
    this_quote = Quote.objects.get(user=user, author=author, quote=user.quote)
    if request.GET.get('liked') == 'liked':
        author.user_likes.add(this_quote)
    print(f'========================{Author.user_likes}==========================')
    return redirect('/success')

def login(request):
    if User.objects.user_exists(request.POST, request):
        isValid = True
        user = User.objects.get(email=request.POST['email'])
        author = User.objects.get(email=request.POST['email']) # Usr.get gets one object. User.get gets an array of users
        request.session['email'] = user.email
        request.session['first_name'] = user.first_name
        request.session['last_name'] = user.last_name
        request.session['id'] = user.id
        request.session['auth_id'] = author.user
        return redirect('/success')
    else:
        isValid = False
        return redirect('/')

def logout(request):
    request.session.clear()
    return redirect('/')
