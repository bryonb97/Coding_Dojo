from django.apps import AppConfig


class QuoteDashConfig(AppConfig):
    name = 'quote_dash'
