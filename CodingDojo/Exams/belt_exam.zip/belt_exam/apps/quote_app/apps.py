from django.apps import AppConfig


class QuoteAppConfig(AppConfig):
    name = 'quote_app'
